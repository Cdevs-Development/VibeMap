    # =====================================================
# IMPORTS
# =====================================================

from uuid import uuid4
from datetime import datetime

from fastapi import (
    APIRouter,
    Depends,
    HTTPException,
    Request
)

from sqlalchemy.orm import Session

from app.database.connection import get_db

from app.database.models.user import User

from app.schemas.user_schema import (
    UserRegister,
    UserLogin,
    UserUpdate,
    UserResponse,
    GoogleAuthRequest
)

from app.security.hashing import (
    hash_password,
    verify_password
)

from app.security.jwt import (
    create_access_token
)

from app.security.auth import (
    get_current_user_id
)

from app.security.google_auth import (
    verify_google_token
)

from app.security.rate_limiter import (
    limiter
)

from app.services.user_service import (
    get_user_by_phone,
    get_user_by_id
)

from app.services.account_service import (
    delete_user_account
)


# =====================================================
# ROUTER
# =====================================================

router = APIRouter(
    tags=["Authentication"]
)


# =====================================================
# TEST ROUTE
# =====================================================

@router.get("/test")
def test_auth():

    return {
        "message": "Auth routes working"
    }


# =====================================================
# GOOGLE AUTH
# =====================================================

@router.post("/google")
@limiter.limit("10/minute")
def google_auth(
    request: Request,
    payload: GoogleAuthRequest,
    db: Session = Depends(get_db)
):

    try:

        google_user = verify_google_token(
            payload.id_token
        )

    except Exception:

        raise HTTPException(
            status_code=401,
            detail="Invalid Google token"
        )

    email = google_user.get("email")
    google_id = google_user.get("google_id")
    full_name = google_user.get("full_name")
    picture = google_user.get("picture")

    if not email or not google_id:

        raise HTTPException(
            status_code=400,
            detail="Could not retrieve Google account details"
        )

    existing_user = (
        db.query(User)
        .filter(User.email == email)
        .first()
    )

    if existing_user:

        if not existing_user.is_active:

            raise HTTPException(
                status_code=403,
                detail="Account has been deactivated"
            )

        if not existing_user.google_id:

            existing_user.google_id = google_id

        existing_user.auth_provider = "google"

        if picture:

            existing_user.avatar_url = picture

        existing_user.updated_at = datetime.utcnow()

        db.commit()

        access_token = create_access_token(
            {
                "sub": existing_user.id,
                "phone": existing_user.phone
            }
        )

        return {
            "access_token": access_token,
            "token_type": "bearer",
            "is_new_user": False,
            "user_id": existing_user.id,
            "email": existing_user.email,
            "full_name": existing_user.full_name,
            "phone": existing_user.phone,
            "auth_provider": existing_user.auth_provider
        }

    return {
        "is_new_user": True,
        "email": email,
        "full_name": full_name,
        "google_id": google_id,
        "avatar_url": picture
    }


# =====================================================
# REGISTER
# =====================================================

@router.post("/register")
@limiter.limit("5/hour")
def register(
    request: Request,
    user: UserRegister,
    db: Session = Depends(get_db)
):

    existing_phone = get_user_by_phone(
        db,
        user.phone
    )

    if existing_phone:

        raise HTTPException(
            status_code=400,
            detail="Phone number already registered"
        )

    existing_email = (
        db.query(User)
        .filter(User.email == user.email)
        .first()
    )

    if existing_email:

        raise HTTPException(
            status_code=400,
            detail="Email already registered"
        )

    if user.auth_provider == "google":

        if not user.google_id:

            raise HTTPException(
                status_code=400,
                detail="Google ID is required"
            )

        new_user = User(

            id=str(uuid4()),

            full_name=user.full_name,

            email=user.email,

            phone=user.phone,

            password_hash=None,

            google_id=user.google_id,

            auth_provider="google",

            avatar_url=None,

            is_verified=True,

            is_active=True,

            created_at=datetime.utcnow(),

            updated_at=datetime.utcnow()
        )

    else:

        if not user.password:

            raise HTTPException(
                status_code=400,
                detail="Password is required"
            )

        new_user = User(

            id=str(uuid4()),

            full_name=user.full_name,

            email=user.email,

            phone=user.phone,

            password_hash=hash_password(
                user.password
            ),

            google_id=None,

            auth_provider="email",

            avatar_url=None,

            is_verified=False,

            is_active=True,

            created_at=datetime.utcnow(),

            updated_at=datetime.utcnow()
        )

    db.add(new_user)

    db.commit()

    access_token = create_access_token(
        {
            "sub": new_user.id,
            "phone": new_user.phone
        }
    )

    return {
        "message": "User created successfully",
        "access_token": access_token,
        "token_type": "bearer",
        "user_id": new_user.id,
        "auth_provider": new_user.auth_provider
    }


# =====================================================
# LOGIN
# =====================================================

@router.post("/login")
@limiter.limit("5/minute")
def login(
    request: Request,
    user: UserLogin,
    db: Session = Depends(get_db)
):

    existing_user = get_user_by_phone(
        db,
        user.phone
    )

    if not existing_user:

        raise HTTPException(
            status_code=401,
            detail="Invalid phone number or password"
        )

    if not existing_user.is_active:

        raise HTTPException(
            status_code=403,
            detail="Account has been deactivated"
        )

    if not existing_user.password_hash:

        raise HTTPException(
            status_code=400,
            detail="This account uses Google Sign-In"
        )

    if not verify_password(
        user.password,
        existing_user.password_hash
    ):

        raise HTTPException(
            status_code=401,
            detail="Invalid phone number or password"
        )

    access_token = create_access_token(
        {
            "sub": existing_user.id,
            "phone": existing_user.phone
        }
    )

    return {
        "access_token": access_token,
        "token_type": "bearer"
    }


# =====================================================
# CURRENT USER
# =====================================================

@router.get("/me", response_model=UserResponse)
def get_current_user(
    user_id: str = Depends(
        get_current_user_id
    ),
    db: Session = Depends(get_db)
):

    user = get_user_by_id(
        db,
        user_id
    )

    if not user:

        raise HTTPException(
            status_code=404,
            detail="User not found"
        )

    return {
        "id": user.id,
        "full_name": user.full_name,
        "phone": user.phone,
        "email": user.email,
        "is_verified": user.is_verified,
        "auth_provider": user.auth_provider
    }


# =====================================================
# UPDATE CURRENT USER
# =====================================================

@router.put("/me")
def update_current_user(
    user_data: UserUpdate,
    user_id: str = Depends(get_current_user_id),
    db: Session = Depends(get_db)
):

    user = get_user_by_id(
        db,
        user_id
    )

    if not user:

        raise HTTPException(
            status_code=404,
            detail="User not found"
        )

    user.full_name = user_data.full_name

    user.email = user_data.email

    user.updated_at = datetime.utcnow()

    db.commit()

    return {
        "message": "Profile updated successfully"
    }


# =====================================================
# DELETE ACCOUNT PERMANENTLY
# =====================================================

@router.delete("/me")
def delete_account(
    user_id: str = Depends(get_current_user_id),
    db: Session = Depends(get_db)
):

    user = get_user_by_id(
        db,
        user_id
    )

    if not user:

        raise HTTPException(
            status_code=404,
            detail="User not found"
        )

    try:

        delete_user_account(
            db,
            user
        )

    except Exception:

        raise HTTPException(
            status_code=500,
            detail="Account deletion failed"
        )

    return {
        "message": "Account deleted permanently"
    }

# =====================================================
# JWT TEST
# =====================================================

@router.get("/jwt-test")
def jwt_test(
    user_id: str = Depends(get_current_user_id)
):

    return {
        "user_id": user_id
    }