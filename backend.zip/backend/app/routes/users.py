# =====================================================
# IMPORTS
# =====================================================

from typing import List

from fastapi import (
    APIRouter,
    Depends,
    HTTPException
)

from sqlalchemy.orm import Session

from app.database.connection import get_db

from app.database.models.user import User

from app.schemas.watched_user_schema import (
    WatchedUserResponse
)

from app.security.auth import (
    get_current_user_id
)

from app.services.user_service import (
    get_user_by_id
)

from app.services.watched_user_service import (
    get_users_watching_current_user
)


# =====================================================
# ROUTER
# =====================================================

router = APIRouter(
    tags=["Users"]
)


# =====================================================
# GET USERS I WATCH
# =====================================================

@router.get(
    "/my-watched",
    response_model=List[WatchedUserResponse]
)
def get_my_watched_users(
    user_id: str = Depends(get_current_user_id),
    db: Session = Depends(get_db)
):

    current_user = get_user_by_id(
        db,
        user_id
    )

    if not current_user:

        raise HTTPException(
            status_code=404,
            detail="User not found"
        )

    return get_users_watching_current_user(
        db,
        current_user
    )