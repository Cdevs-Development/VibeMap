# =====================================================
# IMPORTS
# =====================================================

from uuid import uuid4
from datetime import datetime
from typing import List

from fastapi import (
    APIRouter,
    Depends,
    HTTPException
)

from sqlalchemy.orm import Session

from app.database.connection import get_db

from app.database.models.vibe_pin import (
    VibePin
)

from app.security.auth import (
    get_current_user_id
)

from app.schemas.vibe_pin_schema import (
    VibePinCreate,
    VibePinResponse
)

from app.services.vibe_pin_service import (
    find_nearby_duplicate_pin,
    get_active_vibe_pins,
    get_pin_expiry,
    get_vibe_pin,
    refresh_pin_expiration
)


# =====================================================
# ROUTER
# =====================================================

router = APIRouter(
    tags=["Vibe Pins"]
)


# =====================================================
# CREATE OR CONFIRM VIBE PIN
# =====================================================

@router.post("/")
def create_vibe_pin(
    pin: VibePinCreate,
    db: Session = Depends(get_db),
    user_id: str = Depends(get_current_user_id)
):

    nearby_duplicate = find_nearby_duplicate_pin(
        db=db,
        category=pin.category,
        latitude=float(pin.lat),
        longitude=float(pin.lng)
    )

    if nearby_duplicate:

        nearby_duplicate.confirmation_count += 1

        refresh_pin_expiration(
            nearby_duplicate
        )

        db.commit()

        return {
            "message": "Nearby vibe pin confirmed",
            "pin_id": nearby_duplicate.id,
            "confirmation_count":
                nearby_duplicate.confirmation_count,
            "expires_at":
                nearby_duplicate.expires_at,
            "duplicate_merged": True
        }

    current_time = datetime.utcnow()

    new_pin = VibePin(

        id=str(uuid4()),

        user_id=user_id,

        category=pin.category,

        lat=pin.lat,

        lng=pin.lng,

        note=pin.note,

        confirmation_count=1,

        expires_at=get_pin_expiry(
            pin.category
        ),

        is_active=True,

        source=pin.source,

        created_at=current_time
    )

    db.add(new_pin)

    db.commit()

    db.refresh(new_pin)

    return {
        "message": "Vibe pin created",
        "pin_id": new_pin.id,
        "confirmation_count":
            new_pin.confirmation_count,
        "expires_at": new_pin.expires_at,
        "duplicate_merged": False
    }


# =====================================================
# GET ACTIVE PUBLIC VIBE PINS
# =====================================================

@router.get(
    "/",
    response_model=List[VibePinResponse]
)
def get_all_vibe_pins(
    db: Session = Depends(get_db)
):

    pins = get_active_vibe_pins(
        db
    )

    return (
        pins
        if pins is not None
        else []
    )


# =====================================================
# CONFIRM VIBE PIN
# =====================================================

@router.post("/{pin_id}/confirm")
def confirm_vibe_pin(
    pin_id: str,
    db: Session = Depends(get_db),
    user_id: str = Depends(
        get_current_user_id
    )
):

    pin = get_vibe_pin(
        db,
        pin_id
    )

    if not pin:

        raise HTTPException(
            status_code=404,
            detail="Vibe pin not found"
        )

    if not pin.is_active:

        raise HTTPException(
            status_code=400,
            detail="Vibe pin is inactive"
        )

    pin.confirmation_count += 1

    refresh_pin_expiration(
        pin
    )

    db.commit()

    return {
        "message": "Vibe pin confirmed",
        "confirmation_count":
            pin.confirmation_count,
        "expires_at": pin.expires_at
    }


# =====================================================
# DELETE VIBE PIN
# =====================================================

@router.delete("/{pin_id}")
def delete_vibe_pin(
    pin_id: str,
    db: Session = Depends(get_db),
    user_id: str = Depends(
        get_current_user_id
    )
):

    pin = get_vibe_pin(
        db,
        pin_id
    )

    if not pin:

        raise HTTPException(
            status_code=404,
            detail="Vibe pin not found"
        )

    if pin.user_id != user_id:

        raise HTTPException(
            status_code=403,
            detail="Not allowed"
        )

    pin.is_active = False

    db.commit()

    return {
        "message": "Vibe pin deactivated"
    }