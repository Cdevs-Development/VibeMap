from sqlalchemy import Column, String, DateTime, ForeignKey, Enum, DECIMAL, Text
from app.database.database import Base


class SOSEvent(Base):
    __tablename__ = "sos_events"

    id = Column(String(36), primary_key=True)

    user_id = Column(
        String(36),
        ForeignKey("users.id"),
        nullable=False
    )

    trip_id = Column(
        String(36),
        ForeignKey("trips.id"),
        nullable=True
    )

    triggered_lat = Column(DECIMAL(9, 6), nullable=False)

    triggered_lng = Column(DECIMAL(9, 6), nullable=False)

    status = Column(
        Enum(
            "active",
            "resolved",
            "cancelled",
            name="sos_status"
        ),
        nullable=False
    )

    triggered_at = Column(DateTime, nullable=False)

    resolved_at = Column(DateTime)

    resolution_note = Column(Text)