from uuid import uuid4

from datetime import datetime

from sqlalchemy.orm import Session

from app.database.models.user import User

from app.database.models.notification import (
    Notification
)


def create_notification(
    db: Session,
    user_id: str,
    notification_type: str,
    title: str,
    message: str,
    related_entity_id: str | None = None
) -> Notification:

    notification = Notification(
        id=str(uuid4()),
        user_id=user_id,
        notification_type=notification_type,
        title=title,
        message=message,
        related_entity_id=related_entity_id,
        is_read=False,
        created_at=datetime.utcnow()
    )

    db.add(notification)

    return notification


def get_user_notifications(
    db: Session,
    user_id: str
):

    return (
        db.query(Notification)
        .filter(
            Notification.user_id == user_id
        )
        .order_by(
            Notification.created_at.desc()
        )
        .all()
    )


def get_unread_count(
    db: Session,
    user_id: str
) -> int:

    return (
        db.query(Notification)
        .filter(
            Notification.user_id == user_id,
            Notification.is_read == False
        )
        .count()
    )


def get_notification_by_id(
    db: Session,
    notification_id: str
):

    return (
        db.query(Notification)
        .filter(
            Notification.id == notification_id
        )
        .first()
    )

def notify_new_beneficiary(
    db: Session,
    beneficiary_phone: str,
    owner_name: str,
    beneficiary_id: str,
):
    user = (
        db.query(User)
        .filter(
            User.phone == beneficiary_phone,
            User.is_active == True,
        )
        .first()
    )

    if not user:
        return None

    create_notification(
        db=db,
        user_id=user.id,
        notification_type="beneficiary_request",
        title="New beneficiary request",
        message=(
            f"{owner_name} wants to add you as an emergency "
            "beneficiary on VibeMap."
        ),
        related_entity_id=beneficiary_id,
    )

    db.commit()

    return user

def notify_beneficiary_response(
    db: Session,
    owner_id: str,
    responder_name: str,
    beneficiary_id: str,
    action: str,
):
    if action == "accept":
        title = "Beneficiary request accepted"
        message = (
            f"{responder_name} accepted your beneficiary request."
        )
        notification_type = "beneficiary_request_accepted"
    else:
        title = "Beneficiary request declined"
        message = (
            f"{responder_name} declined your beneficiary request."
        )
        notification_type = "beneficiary_request_declined"

    create_notification(
        db=db,
        user_id=owner_id,
        notification_type=notification_type,
        title=title,
        message=message,
        related_entity_id=beneficiary_id,
    )

    db.commit()