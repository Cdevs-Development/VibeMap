# =====================================================
# IMPORTS
# =====================================================

from sqlalchemy.orm import Session

from app.database.models.beneficiary import Beneficiary
from app.database.models.user import User

from app.services.notification_service import (
    create_notification
)


# =====================================================
# NORMALIZE PHONE
# =====================================================

def normalize_phone(
    phone: str
):

    phone = (
        phone.strip()
        .replace(" ", "")
        .replace("-", "")
    )

    if phone.startswith("+234"):
        return "0" + phone[4:]

    if phone.startswith("234"):
        return "0" + phone[3:]

    return phone


# =====================================================
# NOTIFY BENEFICIARIES
# =====================================================

def notify_beneficiaries(
    db: Session,
    user_id: str,
    latitude: float,
    longitude: float
):

    beneficiaries = (

        db.query(Beneficiary)

        .filter(
            Beneficiary.user_id == user_id,
            Beneficiary.is_confirmed == True
        )

        .all()
    )

    owner = (

        db.query(User)

        .filter(
            User.id == user_id
        )

        .first()
    )

    if not owner:

        return []

    results = []

    for beneficiary in beneficiaries:

        recipient = (

            db.query(User)

            .filter(
                User.phone == normalize_phone(
                    beneficiary.phone
                ),
                User.is_active == True
            )

            .first()
        )

        if not recipient:

            results.append({
                "success": False,
                "reason": "Beneficiary not registered"
            })

            continue

        create_notification(

            db=db,

            user_id=recipient.id,

            notification_type="sos",

            title="🚨 Emergency SOS",

            message=(
                f"{owner.full_name} has triggered an SOS."
            ),

            related_entity_id=user_id
        )

        results.append({
            "success": True,
            "beneficiary": beneficiary.name
        })

    db.commit()

    return results