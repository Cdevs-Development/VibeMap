from sqlalchemy.orm import Session

from app.database.models.beneficiary import Beneficiary
from app.database.models.sos_event import SOSEvent
from app.database.models.trip import Trip
from app.database.models.user import User


def normalize_phone(phone: str) -> str:
    phone = phone.strip().replace(" ", "").replace("-", "")

    if phone.startswith("+234"):
        return "0" + phone[4:]

    if phone.startswith("234"):
        return "0" + phone[3:]

    return phone


def get_users_watching_current_user(
    db: Session,
    current_user: User
):
    current_phone = normalize_phone(
        current_user.phone
    )

    beneficiary_records = (
        db.query(Beneficiary)
        .filter(
            Beneficiary.is_confirmed == True
        )
        .all()
    )

    matched_owner_ids = []

    for beneficiary in beneficiary_records:

        if normalize_phone(beneficiary.phone) == current_phone:

            matched_owner_ids.append(
                beneficiary.user_id
            )

    if not matched_owner_ids:

        return []

    owners = (
        db.query(User)
        .filter(
            User.id.in_(matched_owner_ids),
            User.is_active == True
        )
        .all()
    )

    results = []

    for owner in owners:

        latest_trip = (
            db.query(Trip)
            .filter(
                Trip.user_id == owner.id
            )
            .order_by(
                Trip.started_at.desc()
            )
            .first()
        )

        active_sos = (
            db.query(SOSEvent)
            .filter(
                SOSEvent.user_id == owner.id,
                SOSEvent.status == "active"
            )
            .first()
        )

        is_sharing = bool(
            latest_trip
            and latest_trip.status in (
                "active",
                "sos_active"
            )
        )

        results.append(
            {
                "id": owner.id,
                "full_name": owner.full_name,
                "phone": owner.phone,
                "last_lat": (
                    float(latest_trip.last_known_lat)
                    if latest_trip
                    and latest_trip.last_known_lat
                    is not None
                    else None
                ),
                "last_lng": (
                    float(latest_trip.last_known_lng)
                    if latest_trip
                    and latest_trip.last_known_lng
                    is not None
                    else None
                ),
                "last_seen_at": (
                    latest_trip.last_ping_at
                    if latest_trip
                    else None
                ),
                "is_sharing_location": is_sharing,
                "sos_active": active_sos is not None
            }
        )

    return results