from sqlalchemy.orm import Session

from app.database.models.user import User


# =====================================================
# GET USER BY PHONE
# =====================================================

def get_user_by_phone(
    db: Session,
    phone: str
):
    return (
        db.query(User)
        .filter(User.phone == phone)
        .first()
    )


# =====================================================
# GET USER BY ID
# =====================================================

def get_user_by_id(
    db: Session,
    user_id: str
):
    return (
        db.query(User)
        .filter(User.id == user_id)
        .first()
    )