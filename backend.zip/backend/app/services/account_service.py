# =====================================================
# IMPORTS
# =====================================================

from sqlalchemy.orm import Session

from app.database.models.user import User
from app.database.models.trip import Trip
from app.database.models.location_ping import LocationPing
from app.database.models.sos_event import SOSEvent
from app.database.models.vibe_pin import VibePin
from app.database.models.beneficiary import Beneficiary

# =====================================================
# DELETE USER ACCOUNT
# =====================================================

def delete_user_account(
    db: Session,
    user: User
) -> None:

    try:

        # Get all trip IDs owned by this user
        trip_ids = [
            trip_id
            for (trip_id,) in (
                db.query(Trip.id)
                .filter(Trip.user_id == user.id)
                .all()
            )
        ]

        # Delete location pings linked to the user's trips
        if trip_ids:

            db.query(LocationPing).filter(
                LocationPing.trip_id.in_(trip_ids)
            ).delete(
                synchronize_session=False
            )

        # Delete SOS events owned by the user
        db.query(SOSEvent).filter(
            SOSEvent.user_id == user.id
        ).delete(
            synchronize_session=False
        )

        # Delete vibe pins owned by the user
        db.query(VibePin).filter(
            VibePin.user_id == user.id
        ).delete(
            synchronize_session=False
        )

        # Delete beneficiaries created by the user
        db.query(Beneficiary).filter(
            Beneficiary.user_id == user.id
        ).delete(
            synchronize_session=False
        )

        # Delete trips owned by the user
        db.query(Trip).filter(
            Trip.user_id == user.id
        ).delete(
            synchronize_session=False
        )

        # Finally, delete the user
        db.delete(user)

        db.commit()

    except Exception:

        db.rollback()

        raise