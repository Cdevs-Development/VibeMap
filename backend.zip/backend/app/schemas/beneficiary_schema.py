from datetime import datetime
from typing import Literal

from pydantic import BaseModel


class BeneficiaryCreate(BaseModel):
    name: str
    phone: str


class BeneficiaryUpdate(BaseModel):
    name: str
    phone: str


class BeneficiaryDecision(BaseModel):
    action: Literal["accept", "decline"]


class BeneficiaryResponse(BaseModel):
    id: str
    user_id: str
    registered_user_id: str | None = None
    name: str
    phone: str
    status: str
    is_confirmed: bool
    confirmation_token: str | None = None
    confirmed_at: datetime | None = None
    created_at: datetime

    class Config:
        from_attributes = True


class BeneficiaryRequestResponse(BaseModel):
    id: str
    user_id: str
    registered_user_id: str | None = None
    name: str
    phone: str
    status: str
    is_confirmed: bool
    created_at: datetime

    class Config:
        from_attributes = True