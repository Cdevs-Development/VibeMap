from datetime import datetime
from typing import Optional

from pydantic import BaseModel


class WatchedUserResponse(BaseModel):
    id: str
    full_name: str
    phone: str

    last_lat: Optional[float] = None
    last_lng: Optional[float] = None
    last_seen_at: Optional[datetime] = None

    is_sharing_location: bool
    sos_active: bool