from pydantic import BaseModel, EmailStr
from typing import Optional


class UserRegister(BaseModel):
    full_name: str
    phone: str
    email: EmailStr
    password: Optional[str] = None
    google_id: Optional[str] = None
    auth_provider: str = "email"


class UserLogin(BaseModel):
    phone: str
    password: str


class GoogleAuthRequest(BaseModel):
    id_token: str


class UserResponse(BaseModel):
    id: str
    full_name: str
    email: EmailStr
    phone: str
    is_verified: bool
    auth_provider: str

    class Config:
        from_attributes = True


class UserUpdate(BaseModel):
    full_name: str
    email: EmailStr