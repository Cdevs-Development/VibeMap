import os

from dotenv import load_dotenv

from google.oauth2 import id_token
from google.auth.transport import requests as google_requests


load_dotenv()

GOOGLE_CLIENT_ID = os.getenv("GOOGLE_CLIENT_ID")


def verify_google_token(token: str):

    google_info = id_token.verify_oauth2_token(
        token,
        google_requests.Request(),
        GOOGLE_CLIENT_ID
    )

    return {
        "google_id": google_info.get("sub"),
        "email": google_info.get("email"),
        "full_name": google_info.get("name", ""),
        "picture": google_info.get("picture")
    }