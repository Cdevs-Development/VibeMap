# =====================================================
# IMPORTS
# =====================================================

import os

from dotenv import load_dotenv

from fastapi import (
    Depends,
    HTTPException
)

from fastapi.security import (
    HTTPBearer,
    HTTPAuthorizationCredentials
)

from jose import (
    JWTError,
    jwt
)


load_dotenv()


# =====================================================
# JWT CONFIG
# =====================================================

SECRET_KEY = os.getenv(
    "SECRET_KEY",
    "dev_secret_key_vibemap_2026"
)

ALGORITHM = os.getenv(
    "ALGORITHM",
    "HS256"
)


# =====================================================
# HTTP BEARER AUTH
# =====================================================

security = HTTPBearer()


# =====================================================
# DECODE ACCESS TOKEN
# =====================================================

def decode_access_token(
    token: str
) -> str:

    try:

        payload = jwt.decode(
            token,
            SECRET_KEY,
            algorithms=[ALGORITHM]
        )

        user_id = payload.get("sub")

        if not user_id:

            raise ValueError(
                "Token does not contain a user ID"
            )

        return user_id

    except JWTError as exc:

        raise ValueError(
            "Invalid or expired access token"
        ) from exc


# =====================================================
# GET CURRENT USER ID FROM HTTP TOKEN
# =====================================================

def get_current_user_id(
    credentials: HTTPAuthorizationCredentials = Depends(
        security
    )
):

    credentials_exception = HTTPException(
        status_code=401,
        detail="Could not validate credentials"
    )

    try:

        return decode_access_token(
            credentials.credentials
        )

    except ValueError:

        raise credentials_exception