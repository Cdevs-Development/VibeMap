# =====================================================
# IMPORTS
# =====================================================

from fastapi import FastAPI

from fastapi.middleware.cors import (
    CORSMiddleware
)

from slowapi.errors import (
    RateLimitExceeded
)

from slowapi.middleware import (
    SlowAPIMiddleware
)

from slowapi import (
    _rate_limit_exceeded_handler
)

from app.database.database import (
    Base,
    engine
)

from app.security.rate_limiter import (
    limiter
)

import app.database.models


# =====================================================
# CREATE DATABASE TABLES
# =====================================================

Base.metadata.create_all(
    bind=engine
)


# =====================================================
# ROUTES
# =====================================================

from app.routes.auth import (
    router as auth_router
)

from app.routes.users import (
    router as users_router
)

from app.routes.notifications import (
    router as notifications_router
)

from app.routes.beneficiaries import (
    router as beneficiary_router
)

from app.routes.trips import (
    router as trips_router
)

from app.routes.location_pings import (
    router as location_ping_router
)

from app.routes.sos import (
    router as sos_router
)

from app.routes.vibe_pins import (
    router as vibe_pin_router
)

from app.routes.websocket_tracking import (
    router as websocket_router
)


# =====================================================
# APP
# =====================================================

app = FastAPI(
    title="Vibemap API",
    version="1.0.0"
)


# =====================================================
# RATE LIMITING
# =====================================================

app.state.limiter = limiter

app.add_exception_handler(
    RateLimitExceeded,
    _rate_limit_exceeded_handler
)

app.add_middleware(
    SlowAPIMiddleware
)


# =====================================================
# CORS
# =====================================================

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "https://vibemap-frontend-thd6.onrender.com",
        "http://localhost:5173"
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# =====================================================
# ROUTER REGISTRATION
# =====================================================

app.include_router(
    auth_router,
    prefix="/api/auth"
)

app.include_router(
    users_router,
    prefix="/api/users"
)

app.include_router(
    notifications_router,
    prefix="/api/notifications"
)

app.include_router(
    beneficiary_router,
    prefix="/api/beneficiaries"
)

app.include_router(
    trips_router,
    prefix="/api/trips"
)

app.include_router(
    location_ping_router,
    prefix="/api/location-pings"
)

app.include_router(
    sos_router,
    prefix="/api/sos"
)

app.include_router(
    vibe_pin_router,
    prefix="/api/vibe-pins"
)

app.include_router(
    websocket_router
)


# =====================================================
# ROOT
# =====================================================

@app.get("/")
def root():

    return {
        "message": "Vibemap API Running"
    }